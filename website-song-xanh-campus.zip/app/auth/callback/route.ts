import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function GET(request: Request) {
  const url = new URL(request.url)
  const code = url.searchParams.get('code')
  if (code) {
    const supabase = await createClient()
    const { error } = await supabase.auth.exchangeCodeForSession(code)
    if (error) return NextResponse.redirect(new URL('/auth/login?error=callback', request.url))
  } else {
    return NextResponse.redirect(new URL('/auth/login?error=callback', request.url))
  }
  return NextResponse.redirect(new URL('/profile', request.url))
}
